import { Component } from "@angular/core";

@Component({
  selector: "app-home",
  templateUrl: "home.page.html",
  styleUrls: ["home.page.scss"],
})
export class HomePage {
  selecoes = [
    'brasil.png',
    'portugal.png'
  ]
  imagem = 'inicio.jpg'

  constructor() {}

  trocar(indice: number): void{
    this.imagem = this.selecoes[indice]
  }
}

